// This is a comment

/*
This is a 
multiline comment
*/

// Printing things to console
console.log("HERE");

// Variable declaration
var a = 1; // Old way - Deprecated - Doesnt handle scope well - Ignores {block scope}
let b = 2; // New way - Handles scope well - Respects {block scope}
const c = 3; // Constant declaration

// Not constant variables can change values and types
let x = 1;
// console.log(x);
x = "Test";
// console.log(x);

// *****************  Scope example var vs let ***************** 
for (let i = 0; i < 5; i++) {
    console.log('Hello Worlds');
    let k = "I respect the block scope";
    var l = "I don't respect the block scope";
}

console.log(l); // Works
// console.log(k); // Error
// console.log(i); // Works only if 'i' is declared as var
// let l = "Redeclaration"; // Throws error if l is declared with var


// Function declaration
// Use traditional function when you need this, new, etc.
function myFunction(x) { // Old way
    const y = x ** 2;
    return y;
};
// console.log(myFunction(2));

// Use arrow function for short/inline callbacks, event handlers, and functional programming.
const myFunction2 = (x) => { // New way
    const y = x ** 2;
    return y;
}
// console.log(myFunction2(2));

/*
Callback/Function declaration:
() => {}
(arguments) => {function body}
*/

// Array declaration
const arr = [];
arr.push(1); // Add element to array
arr.push(2); // Add element to array
// console.log(arr);
const poppedValue = arr.pop(); // Remove last element from array
// console.log(arr);
// console.log(poppedValue);

arr.push(3);
arr.forEach((el) => { console.log(el); }); // Iterate over array
const arr2 = arr.map((el) => el * 2); // Map array elements to new array

// Object declaration
const obj = {};
obj.x = 1;
obj.y = 2;
obj.insideObj = {};
obj.insideObj.x = 1;
// console.log(obj.insideObj.x);
// console.log(obj.y.x.a); // Error

if (obj && obj.y && obj.y.x && obj.y.x.a) { // Check if object exists
    console.log(obj.y.x.a);
}
if (obj?.y?.x?.a) { // Check if object exists
    console.log(obj.y.x.a);
}

// Strong (Checks value and type) vs Loose (Checks value only) equality/inequality
console.log(1 == '1'); // true
console.log(1 === '1'); // false
console.log(1 != '1'); // false
console.log(1 !== '1'); // true
console.log(0 == false); // true
console.log(0 === false); // false
console.log(null == undefined); // true
console.log(null === undefined); // false

// Conditional statements
if (a === 2 && c !== 4) {
    console.log("a=2");
} else if (a === 2 && c === 4) {
    console.log("Here");
} else {
    console.log("Unknown a");
}

// Switch statement
switch (a) {
    case 2:
        console.log("a is 2");
        break;
    case 3:
        console.log("a is 3");
        break;
    default:
        console.log("Unknown a");
}

// Basic for loop
for (let i = 0; i <= 5; i++) {
    console.log(i);
}

// Iterate over array
const arr3 = [1,2,3,4,5];
for (const it of arr2) {
    console.log(it);
}

// Iterate over object
for (const [key, value] of Object.entries(obj)) {
    console.log(`${key}: ${value}`);
}


// ***************** Objects flexibility *****************
const car = {
  brand: "Toyota",      // data (property)
  speed: 0,             // data (property)
  
  // method (behavior)
  accelerate() {
    this.speed += 10;
    console.log(`${this.brand} is now going at ${this.speed} km/h`);
  },

  brake() {
    this.speed -= 5;
    console.log(`${this.brand} slowed down to ${this.speed} km/h`);
  }
};

console.log(car.brand); // Toyota
console.log(car.speed); // 0
car.accelerate(); // Toyota is now going at 10 km/h
console.log(car.speed); // 10

// ***************** Classes *****************

class Bicycle {
    constructor(model) {
        this.model = model;
        this.speed = 0;
    }

    pedal() {
        this.speed += 5;
        console.log(`${this.model} pedaled to ${this.speed} km/h`);
    }

    brake() {
        this.speed = Math.max(0, this.speed - 3);
        console.log(`${this.model} slowed to ${this.speed} km/h`);
    }
}

const myBike = new Bicycle("Montana");
console.log(myBike.model); // Montana
console.log(myBike.speed); // 0
myBike.pedal(); // Montana pedaled to 5 km/h
console.log(myBike.speed); // 5
